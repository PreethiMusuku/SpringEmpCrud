import { Component, OnInit } from '@angular/core';
import { Employee, SEmployeeService } from '../s-employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deleteemployee',
  templateUrl: './deleteemployee.component.html',
  styleUrls: ['./deleteemployee.component.css']
})
export class DeleteemployeeComponent implements OnInit {
  user : Employee = new Employee(0,"",0)
  id:number= 0

  constructor(private employeeservice: SEmployeeService, private router: Router) { }

  ngOnInit(): void {
  }

  deleteEmpById():void{
    this.employeeservice.deleteEmpById(this.user).subscribe(data => {});
           this.router.navigate(['/ListEmployees']);

}
}
