export class IEmployee
{
  id:number;
  name:string;
  sal:number;
}