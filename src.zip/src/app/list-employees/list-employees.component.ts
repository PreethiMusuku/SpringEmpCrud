import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../i-employee';
import { SEmployeeService, Employee } from '../s-employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {

  employees: Employee;
  
  constructor(private empService: SEmployeeService,private router: Router) {}

  ngOnInit(): void 
  {
    this.empService.getEmployees().subscribe(
    response =>this.handleSuccessfulResponse(response),
   );
 }

handleSuccessfulResponse(response)
{
   this.employees=response;
}
}
