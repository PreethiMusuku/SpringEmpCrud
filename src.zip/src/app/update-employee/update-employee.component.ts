import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../i-employee';
import { SEmployeeService, Employee } from '../s-employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  user:Employee=new Employee(0,"",0);
    
  constructor(private employeeservice: SEmployeeService, private router: Router) { }

  ngOnInit(): void {
  }


  updateEmp():void{
    this.employeeservice.updateEmp(this.user).subscribe(data => {});
           this.router.navigate(['/ListEmployees']);
  }

}