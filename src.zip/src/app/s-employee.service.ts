import { Injectable } from '@angular/core';
import { IEmployee } from './i-employee';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class SEmployeeService {
  
  constructor(private http:HttpClient) { }
  employee:Employee

  public getEmployees() {
    console.log("test call");
    return this.http.get<Employee>("http://localhost:5646/bank/fetchAll");
  }
  
  public addEmp(user: Employee) {
    console.log(user);
    return this.http.post<Employee>("http://localhost:5646/bank/create", user);
 }
 
 public deleteEmpById(user: Employee) {
    return this.http.delete<Employee>("http://localhost:5646/bank/delete/"+ user.id);
  }


  public  updateEmp(user: Employee) {
    console.log(user);
    return this.http.put<Employee>("http://localhost:5646/bank/update", user);
  }

}

export class Employee
{
  id:number;
  name:string;
  sal:number;

  constructor(id:number, name:string, sal:number)
  {
    this.id=id;
    this.name=name;
    this.sal=sal;
  }
}