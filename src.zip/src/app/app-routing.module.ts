import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { DeleteemployeeComponent } from './deleteemployee/deleteemployee.component';


const routes: Routes = [
{path:'add-employee',component:AddEmployeeComponent},
{path:'ListEmployees',component:ListEmployeesComponent},
{path:'deleteemployee',component:DeleteemployeeComponent},
{path:'update-employee',component:UpdateEmployeeComponent},
{path:'',component:ListEmployeesComponent}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
